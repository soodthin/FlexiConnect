/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.soodthin.dto.request.AI;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 *
 * @author ADMIN
 */
@Data
public class SubmitAnswerRequest {

    private Integer sessionId;
    @NotBlank(message = "Answer is required")
    private String answer;

    private String question;
    private String difficulty;
    private String category;

}
